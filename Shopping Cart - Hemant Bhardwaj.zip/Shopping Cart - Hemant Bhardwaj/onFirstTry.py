import myMongo, data

mongo = myMongo.Mongo()

def create_database():
    try:
        mongo.insert_items(data.getData())
        mongo.insert({"_id":1, "username":"shadow", "password":"dark"}, 'users')
        return True
    except:
        return False

with open('firstTime.dat', 'r+') as file:
    check = file.read()
    print(check)
    if check=="true":
        create_database()
        file.write('false')
    file.close()
