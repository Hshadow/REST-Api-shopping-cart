import pymongo
import data

class Mongo():
    def __init__(self):
        super().__init__()
        self.connSyntex = "mongo -u admin -p 3VUM4BaGqAuV7V27 SG-shadow-37410.servers.mongodirector.com:27017/admin"
        self.localhost = "mongodb://localhost:27017"

        self.myClient = pymongo.MongoClient(self.localhost)

        self.mydb = self.myClient['cart']

        self.mycol = self.mydb['items']

        '''item = {
                '_id':1,
                'name':'Ambrane Micro USB Cable',
                'type':'electronics',
                'price':'260',
                'des':[{'length':'1.6 meters long', 'warranty':'6 months', 'compatible with':'redmi, realme, iphone, apple, vivo, oppo etc.'}]
                }'''
        self.items = data.getData()

    def create_collection(self, col):
        try:
            created = self.mydb[col]
            return (True, created)
        except:
            return (False, None)
            
    def insert(self, data, column):
        try:
            self.create_collection(column)
            print("created")
        except:
            print("exists")
            pass
        try:
            exist = [x for x in self.mydb[column].find({'_id':{"$exists":True, "$in":[data['_id']]}})]
            if len(exist)>0:
                print("exists")
                pass
            else:
                self.mydb[column].insert_one(data)
                print("inserted")
            return True
        except Exception as ex:
            print(ex)
            return False
        
    def insert_items(self,data):
        
        for i in range(len(self.items)):
            item = data[f'{i+1}'][0]
            try:
                exist = [x for x in self.mydb.items.find({'_id':{"$exists":True, "$in":[item['_id']]}})]
                if len(exist)>0:
                    print("exists !")
                else:
                    x = self.mycol.insert_one(item)
                    print("inserted successfully !")
            except Exception as ex:
                print("Error : data not inserted !")

        #print([x for x in mydb.items.find({'_id':{"$exists":True, "$in":[1]}})])

    def get_collection(self, column):
        
        return [x for x in self.mydb[column].find({})]

    def find_data(self, index, find, column):
        exist = [x for x in self.mydb[column].find({index:{"$exists":True, "$in":[find]}})]
        return exist[0]

    def delete(self, col, query):
        try:
            self.mydb[col].delete_one(query)
            print("delete successfully!")
            return True
        except Exception as ex:
            print(f"Delete Error : {ex}")
            return False



if __name__ == "__main__":
    mongo = Mongo()
    #c = mongo.delete('items', {"_id":1})
    #c = mongo.insert_items(data.getData())
    #c = mongo.insert({"_id":1, "username":"shadow", "password":"dark"}, 'users')
    #c = mongo.get_collection("users")
    #c = mongo.find_data("username", "shadow", "users")
    #c = mongo.insert({"_id":6}, 'mycart')
    #c = mongo.get_collection("items")
    #c = mongo.delete('mycart', {'_id':None})
    
    #print(c)
   
