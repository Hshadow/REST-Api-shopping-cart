import json, io

def getData():
    with io.open(file="data.json", encoding="utf-8") as file:
        data = json.load(file)    
        file.close()
    return data

data = getData()
if __name__ == "__main__":
    print(data)
