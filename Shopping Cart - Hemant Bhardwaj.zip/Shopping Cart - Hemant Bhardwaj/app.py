import sys
import os, datetime, jwt, webbrowser
from flask import Flask, render_template, Response, flash, request, redirect, url_for, send_from_directory, Markup,make_response,jsonify, session
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
import data, myMongo
from werkzeug.security import safe_str_cmp
from functools import wraps
import onFirstTry
# initialize a flask object
app = Flask(__name__)
app.config["SECRET_KEY"] = "cmvopawetndfjviawehrjerghlnaipdfhiwekjrnweoifusdjfkbutyhewdf"
identity = 1
uname = "shadow"
pword = "dark"

mongo = myMongo.Mongo()


def token_required(f):
        
        @wraps(f)
        def decorated(*args, **kwargs):
                token = request.args.get('token')
                if not token:
                        return jsonify({'message':'Token is missing'}), 403
                try:
                        data = jwt.decode(token, app.config['SECRET_KEY'])
                except Exception as ex:
                        print("error : ",ex)
                        return "Token is invalid !\nPlease login again !"#jsonify({'message':'Token is invalid ! please login again'}), 403
                return f(*args, **kwargs)
        return decorated


#def index():
 #       return render_template('login.html')
@app.route('/user')
def user():
        return render_template('login.html')
@app.route('/login', methods = ['GET', 'POST'])
def login():
        username = request.values.get("username")
        password = request.values.get("password")

        if not username:
                return "Missing Username", 400
        if not password:
                return "Missing Password", 400

        if username != uname or password != pword:
                return "User Not Found !", 404
        else:
                token = jwt.encode({'user':username, 'exp':datetime.datetime.utcnow()+datetime.timedelta(minutes=10)}, app.config["SECRET_KEY"])#create_access_token(identity={"username":username})
                token = token.decode("UTF-8")
                #return {"access_token":token}
                return render_template("success_login.html", token=token)


# Items
@app.route('/')
@app.route("/items",methods=['GET','POST'])
def items():
        itemID = request.values.get('id')

        try:
                mongo.mydb.mycart.insert_one({"_id":itemID})
        except:
                pass
        
        items=mongo.get_collection('items')
        length = len(items)
        mycart = [[y for y in x.values()][0] for x in mongo.get_collection("mycart")]
                        
        render= render_template('home.html',items=items, length=length, s = str, mycart = mycart)
        return render

#cart

@app.route("/cart",methods=['GET','POST'])
@token_required
def cart():

        if request.values.get('deletecart')=="true":
                mongo.mydb.mycart.drop()
                return render_template('myCart.html',cart = False, items = [], s = str, length = 0)
                
        cart=False
        total_items=True
        
        ids = mongo.get_collection('mycart')
        items = []
        for i in ids:
                if i['_id'] != None:
                        item =  mongo.mydb.items.find({"_id":{"$exists":True, "$in":[int(i['_id'])]}})
                        if item:
                                items.extend(item)
                        else:
                                pass
        if request.values.get('delete') != None:
                d_id=request.values.get('delete')
                print("Delete id : ", d_id)
                mongo.mydb.mycart.delete_one({'_id':d_id})
                ids = mongo.get_collection('mycart')
                items = []
                for i in ids:
                        if i['_id'] != None:
                                item =  mongo.mydb.items.find({"_id":{"$exists":True, "$in":[int(i['_id'])]}})
                                if item:
                                        items.extend(item)
                                else:
                                        pass
                if 'mycart' in mongo.mydb.list_collection_names():
                        cart = True
                
                return render_template('myCart.html',cart = cart, items = items, s = str, length = len(items))
        
        if 'mycart' in mongo.mydb.list_collection_names():
                        cart = True
        
        render= render_template('myCart.html',cart=cart,items=items, s = str, length = len(items))
        return render

@app.route('/newcart',methods=['GET', 'POST'])
def newCart():
        try:
                mongo.mydb['mycart']
                return render_template('cart_success.html')
        except Exception as ex:
                print(f"Error : {ex}")
                return render_template('cart_fail.html')

@app.route('/delete', methods=['GET', 'POST'])
def delete():
        try:
                mongo.mydb['mycart'].drop()
                return url_for('items')
        except:
                return jsonify({"message":"failed to delete cart"}), 400




if __name__=="__main__":
        webbrowser.open_new('http://127.0.0.1:8000')
        app.run(port='8000', debug=True)
        
